<img src="https://i.imgur.com/hgKeRR3.png" />
<p style="text-align: center;"><a title="Join our discord!" href="https://discord.gg/Kss5gBgeDA"><img src="https://img.shields.io/discord/734879752866889788?color=F7F3F5&amp;labelColor=030B14&amp;style=for-the-badge&amp;logo=Discord&amp;label=Discord&amp;logoColor=fe0000" height="28" /></a>&nbsp;<a href="https://wiki.crismpack.net/modpacks/insomnia-hardcore"><img src="https://img.shields.io/badge/Wiki-CrismPack.net-F7F3F5?labelColor=030B14&amp;style=for-the-badge" height="28" /></a>&nbsp;<a href="https://www.curseforge.com/members/crismpack/projects"><img src="https://img.shields.io/badge/Our-Modpacks-F7F3F5?style=for-the-badge&amp;labelColor=030B14&amp;logo=curseforge&amp;logoColor=important" height="28" /></a><span style="font-size: 1.2rem;">&nbsp;</span></p>
<img src="https://i.imgur.com/zt8Kn0i.png" />
Check it out on CurseForge:
https://www.curseforge.com/minecraft/modpacks/insomnia-hardcore
