The server requires 'Java 17' to run.

Hardcore is enabled by default. If that isn't your thing you can simply go ahead and disable it.
To disable Hardcore open the 'server.properties' file and change "hardcore=true" to "hardcore=false".